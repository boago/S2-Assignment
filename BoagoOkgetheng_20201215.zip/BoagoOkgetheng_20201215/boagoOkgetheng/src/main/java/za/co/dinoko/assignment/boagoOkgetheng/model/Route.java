package za.co.dinoko.assignment.boagoOkgetheng.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class Route {

	private int routeId;
	private Planet planetOrigin;
	private Planet planetDestination;
	private double distanceLightYears;

	public Route()
	{
	}
	
	public Route(int id, Planet planetOrigin, Planet planetDestination, double distance)
	
	{
		this.routeId= id;
		this.planetOrigin=planetOrigin;
		this.planetDestination=planetDestination;
		this.distanceLightYears= distance;
		
		
	}
	public int getRouteId() {
		return routeId;
	}


	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}


	

	public double getDistanceLightYears() {
		return distanceLightYears;
	}


	public void setDistanceLightYears(double distanceLightYears) {
		this.distanceLightYears = distanceLightYears;
	}
	
	public Planet getPlanetOrigin() {
		return planetOrigin;
	}
	public void setPlanetOrigin(Planet planetOrigin) {
		this.planetOrigin = planetOrigin;
	}
	public Planet getPlanetDestination() {
		return planetDestination;
	}
	public void setPlanetDestination(Planet planetDestination) {
		this.planetDestination = planetDestination;
	}
	@Override
	public String toString()
	{
		return planetOrigin + " " + planetDestination;
	}
	
	
	

}
