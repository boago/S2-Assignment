package za.co.dinoko.assignment.boagoOkgetheng;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class BoagoOkgethengApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoagoOkgethengApplication.class, args);
	}
	
	/* @PostConstruct
    public void perform() throws Exception {
        JobParameters params = new JobParametersBuilder()
                .addString("JobID", String.valueOf(System.currentTimeMillis()))
                .toJobParameters();
        jobLauncher.run(job, params);
    }
*/
}
