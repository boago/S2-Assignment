package za.co.dinoko.assignment.boagoOkgetheng.planetRepository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;

@Repository
public interface PlanetRepository extends CrudRepository<Planet, String> {

}
