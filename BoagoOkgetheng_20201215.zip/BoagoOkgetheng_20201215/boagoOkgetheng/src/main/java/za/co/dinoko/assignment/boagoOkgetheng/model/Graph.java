package za.co.dinoko.assignment.boagoOkgetheng.model;

import java.util.List;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Graph {
    private final List<Planet> planets;
    private final List<Route> routes;

    public Graph(List<Planet> planets, List<Route> routes) {
        this.planets = planets;
        this.routes = routes;
    }

    public List<Planet> getPlanets() {
        return planets;
    }

    public List<Route> getRoutes() {
        return routes;
    }
}