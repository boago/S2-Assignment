package za.co.dinoko.assignment.boagoOkgetheng.config;

import org.springframework.batch.item.ItemProcessor;

import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;

public class DBLogProcessor implements ItemProcessor<Planet, Planet>
	{
	    public Planet  process(Planet planet) throws Exception
	    {
	        System.out.println("Inserting Planets : " + planet);
	        return planet;
	    }
	}

