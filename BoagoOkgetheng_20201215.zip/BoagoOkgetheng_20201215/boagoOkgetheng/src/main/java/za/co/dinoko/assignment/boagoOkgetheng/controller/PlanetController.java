package za.co.dinoko.assignment.boagoOkgetheng.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;
import za.co.dinoko.assignment.boagoOkgetheng.service.PlanetService;

/* create a restController */

@RestController
public class PlanetController {
	
	/* autowire the PlanetService class */
	
	@Autowired
	PlanetService planetService;

	/* CRUD operations to be handled in this class*/
	/* create a get mapping to retrieve all Planets */
	
	@GetMapping("/planet")
	private List<Planet> getAllPlanet()
	{
		return  planetService.getAllPlanet();	
	}
	
	/* create a get mapping to retrieve details of a specific Planet*/
	
	@GetMapping("/planet/{id}")
	private Planet getPlanet(@PathVariable ("id")String planetNode)
	{
		return  planetService.getPlanet(planetNode);	
	}
	
	/* create a delete mapping to delete a specific planet */
	@DeleteMapping("/planet/{id}")
	private void deletePlanet(@PathVariable ("id")String planetNode)
	{
		planetService.deletePlanet(planetNode);	
	}
	
	/* create a Post mapping to saving planet details */
	@PostMapping("/planet")
	private String savePlanet(@RequestBody Planet planet)
	{
		planetService.saveOrUpdatePlanet(planet);	
		
		return planet.getPlanetNode();
	}
	
	/* create a Post mapping to update planet details */
	@PutMapping("/planet")
	private Planet update(@RequestBody Planet planet)
	{
		planetService.saveOrUpdatePlanet(planet);	
		
		return planet;
	}
}
