package za.co.dinoko.assignment.boagoOkgetheng.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import za.co.dinoko.assignment.boagoOkgetheng.model.Routes;
import za.co.dinoko.assignment.boagoOkgetheng.service.RoutesService;

/* create a restController */

@RestController
public class RoutesController {
/* autowire the RouteService class */
	
	@Autowired
	RoutesService routesService;

	/* CRUD operations to be handled in this class*/
	/* create a get mapping to retrieve all Planets */
	
	@GetMapping("/route")
	private List<Routes> getAllRoutes()
	{
		return  routesService.getAllRoutes();	
	}
	
	/* create a get mapping to retrieve details of a specific Planet*/
	
	@GetMapping("/route/{id}")
	private Routes getPlanet(@PathVariable ("id")int routeId)
	{
		return  routesService.getRoute(routeId);	
	}
	
	/* create a delete mapping to delete a specific planet */
	@DeleteMapping("/route/{id}")
	private void deleteRoute(@PathVariable ("id")int routeId)
	{
		routesService.deleteRoute(routeId);	
	}
	
	/* create a Post mapping to saving planet details */
	@PostMapping("/route")
	private String savePlanet(@RequestBody Routes route)
	{
		routesService.saveOrUpdateRoute(route);	
		
		return route.toString();
	}
	
	/* create a Post mapping to update planet details */
	@PutMapping("/route")
	private Routes update(@RequestBody Routes route)
	{
		routesService.saveOrUpdateRoute(route);	
		
		return route;
	}	

}
