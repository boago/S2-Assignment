package za.co.dinoko.assignment.boagoOkgetheng.config;


import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.zaxxer.hikari.HikariDataSource;

import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;


import javax.sql.DataSource;
	//@Configuration
	//@EnableBatchProcessing
	public class BatchConfig {

//	    @Autowired
//	    private JobBuilderFactory jobBuilderFactory;
//
//	    @Autowired
//	    private StepBuilderFactory stepBuilderFactory;
//
//	    @Value("classPath:/input/planets.csv")
//	    private Resource inputResource;
//
//	    /**
//	     * JobBuilderFactory(JobRepository jobRepository)  Convenient factory for a JobBuilder which sets the JobRepository automatically
//	     */
//	    @Bean
//	    public Job readCSVFileJob() {
//	        return jobBuilderFactory
//	                .get("readCSVFileJob")
//	                .incrementer(new RunIdIncrementer())
//	                .start(step())
//	                .build();
//	    }
//	    
//	    /**
//	     * StepBuilder which sets the JobRepository and PlatformTransactionManager automatically
//	     */
//
//	    @Bean
//	    public Step step() {
//	        return stepBuilderFactory
//	                .get("step")
//	                .<Planet, Planet>chunk(2)
//	                .reader(reader())
//	                .processor(processor())
//	                .writer(writer())
//	                .build();
//	    }
//	    
//	    /**
//	     * Prints the Logs in the console.
//	     * @return
//	     */
//
//	    @Bean
//	    public ItemProcessor<Planet, Planet> processor() {
//	        return new DBLogProcessor();
//	    }
//
//	    /**
//	     * FlatFileItemReader<T> Restartable ItemReader that reads lines from input setResource(Resource).
//	     * @return
//	     */
//	    
//	    @Bean
//	    public FlatFileItemReader<Planet> reader() {
//	        FlatFileItemReader<Planet> itemReader = new FlatFileItemReader<Planet>();
//	        itemReader.setLineMapper(lineMapper());
//	        itemReader.setLinesToSkip(1);
//	        itemReader.setResource(inputResource);
//	        return itemReader;
//	    }
//	    
//
//
//	    /**
//	     * The itemWriter object will set JDBC connection and sql statement is prepared for the batch action we want to perform in the database.
//	     * A convenient implementation for providing BeanPropertySqlParameterSource when the item has JavaBean properties that correspond to names used for parameters in the SQL statement.
//	     *
//	     */
//	    @Bean
//		public DataSource dataSource() {
//			HikariDataSource dataSource = new HikariDataSource();
//			dataSource.setDriverClassName("org.h2.Driver");
//			dataSource.setJdbcUrl("jdbc:h2:mem:planetsdb");
//			dataSource.setUsername("boagoOkgetheng");
//			dataSource.setPassword("");
//			return dataSource;
//		}
//
//	    @Bean
//	    public JdbcBatchItemWriter<Planet> writer() {
//
//	        JdbcBatchItemWriter<Planet> itemWriter = new JdbcBatchItemWriter<Planet>();
//
//	        itemWriter.setDataSource(dataSource());
//	        itemWriter.setSql("INSERT INTO Planet (PLANET_NODE) VALUES ( :Planet Node, :Planet Name)");
//	        itemWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Planet>());
//	        return itemWriter;
//	    }
//
//	    /**
//	     * the lineMapper for mapping lines (strings) to domain objects typically used to map lines read from a file to domain objects on a per line basis.
//	     * lineTokenizer to split string obtained typically from a file into tokens. In our example we are using DelimitedLineTokenizer that is because we are using csv file.
//	     * fieldSetMapper to map data obtained from a FieldSet into an object.
//	     *
//	     */
//
//	    @Bean
//	    public LineMapper<Planet> lineMapper() {
//	        DefaultLineMapper<Planet> lineMapper = new DefaultLineMapper<Planet>();
//	        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
//	        BeanWrapperFieldSetMapper<Planet> fieldSetMapper = new BeanWrapperFieldSetMapper<Planet>();
//
//	        lineTokenizer.setNames(new String[]{"id", "name", "description", "city", "rating" });
//	        lineTokenizer.setIncludedFields(new int[]{0, 1, 2, 3, 4});
//	        fieldSetMapper.setTargetType(Planet.class);
//	        lineMapper.setLineTokenizer(lineTokenizer);
//	        lineMapper.setFieldSetMapper(fieldSetMapper);
//
//	        return lineMapper;
//	    }


	}

