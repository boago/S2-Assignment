package za.co.dinoko.assignment.boagoOkgetheng.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;
import za.co.dinoko.assignment.boagoOkgetheng.planetRepository.PlanetRepository;


/* Service class*/
@Service
public class PlanetService {
	
	@Autowired
	PlanetRepository planetRepository;
	
	/*getting all Planets Records*/
	
public List<Planet> getAllPlanet()
{
	List<Planet> planets = new ArrayList<Planet>(); 
	planetRepository.findAll().forEach(planet -> planets.add(planet));
	return planets;
}

/*getting a specific Planet Record*/
public Planet getPlanet(String planetNode)
{
	return planetRepository.findById(planetNode).get();
	
}

/*deleting a specific planet Record*/
public void deletePlanet(String planetNode)
{
	planetRepository.deleteById(planetNode);
	
}

/*saving a specific Planet Record */
public void saveOrUpdatePlanet(Planet planet)
{
	planetRepository.save(planet);	
}
/*updating a SPlanet Record */
public void updatePlanet(Planet planet, String planetNode)
{
	planetRepository.save(planet);	
}
}
