package za.co.dinoko.assignment.boagoOkgetheng.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import za.co.dinoko.assignment.boagoOkgetheng.model.Routes;
import za.co.dinoko.assignment.boagoOkgetheng.planetRepository.RouteRepository;

@Service
public class RoutesService {
	@Autowired
	RouteRepository routeRepository;
	
	/*getting all routes Records*/
	
public List<Routes> getAllRoutes()
{
	List<Routes> routes = new ArrayList<Routes>(); 
	routeRepository.findAll().forEach(route -> routes.add(route));
	return routes;
}

/*getting a specific Route Record*/
public Routes getRoute(int routeId)
{
	return routeRepository.findById(routeId).get();
	
}

/*deleting a specific route Record*/
public void deleteRoute(int routeId)
{
	routeRepository.deleteById(routeId);
	
}

/*saving a specific Planet Record */
public void saveOrUpdateRoute(Routes route)
{
	routeRepository.save(route);	
}
/*updating a SPlanet Record */
public void updateRoute(Routes route, int routeId)
{
	routeRepository.save(route);	
}

}
