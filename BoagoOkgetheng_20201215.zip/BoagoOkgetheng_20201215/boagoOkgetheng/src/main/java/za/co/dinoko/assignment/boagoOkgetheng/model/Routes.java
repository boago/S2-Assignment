package za.co.dinoko.assignment.boagoOkgetheng.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/* mark class as an Entity */
@Entity

/* mark class name as Table name */
@Table
public class Routes {
	
	/* mark routeId As a primary Key */
	@Id
	
	/* mark routeId as a column name*/
	@Column
	private int routeId;
	
	/* mark planetOrigin as a column name*/
	@Column
	private String planetOrigin;
	
	/* mark planetDestination as a column name*/

	@Column
	private String planetDestination;
	
	/* mark distanceLightYears as a column name*/
	
	@Column
	private double distanceLightYears;

/* constructor*/
	
	public Routes()
	{
	}
	
	public Routes(int id, String planetOrigin, String planetDestination, double distance)
	
	{
		this.routeId= id;
		this.planetOrigin=planetOrigin;
		this.planetDestination=planetDestination;
		this.distanceLightYears= distance;
		
		
	}
	public int getRouteId() {
		return routeId;
	}


	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}


	

	public double getDistanceLightYears() {
		return distanceLightYears;
	}


	public void setDistanceLightYears(double distanceLightYears) {
		this.distanceLightYears = distanceLightYears;
	}
	
	public String getPlanetOrigin() {
		return planetOrigin;
	}
	public void setPlanetOrigin(String planetOrigin) {
		this.planetOrigin = planetOrigin;
	}
	public String getPlanetDestination() {
		return planetDestination;
	}
	public void setPlanetDestination(String planetDestination) {
		this.planetDestination = planetDestination;
	}
	@Override
	public String toString()
	{
		return planetOrigin + " " + planetDestination;
	}
	
	
	

}
