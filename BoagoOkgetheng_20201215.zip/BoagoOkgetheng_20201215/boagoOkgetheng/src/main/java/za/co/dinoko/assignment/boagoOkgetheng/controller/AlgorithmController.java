package za.co.dinoko.assignment.boagoOkgetheng.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import za.co.dinoko.assignment.boagoOkgetheng.model.Graph;
import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;
import za.co.dinoko.assignment.boagoOkgetheng.model.Route;



public class AlgorithmController {
	
	   private final List<Route> routes;
	    private Set<Planet> settledNodes;
	    private Set<Planet> unSettledNodes;
	    private Map<Planet, Planet> predecessors;
	    private Map<Planet, Double> distance;

	    public AlgorithmController (Graph graph) {
	        new ArrayList<Planet>(graph.getPlanets());
	        this.routes = new ArrayList<Route>(graph.getRoutes());
	        
	        
	    }
	    public void execute(Planet source) {
	        settledNodes = new HashSet<Planet>();
	        unSettledNodes = new HashSet<Planet>();
	        distance = new HashMap<Planet, Double>();
	        predecessors = new HashMap<Planet, Planet>();
	        distance.put(source, 0.0);
	        unSettledNodes.add(source);
	        while (unSettledNodes.size() > 0) {
	            Planet node = getMinimum(unSettledNodes);
	            settledNodes.add(node);
	            unSettledNodes.remove(node);
	            findMinimalDistances(node);
	        }
	    }

	    private void findMinimalDistances(Planet node) {
	        List<Planet> adjacentNodes = getNeighbors(node);
	        for (Planet target : adjacentNodes) {
	            if (getShortestDistance(target) > getShortestDistance(node)
	                    + getDistance(node, target)) {
	                distance.put(target, getShortestDistance(node)
	                        + getDistance(node, target));
	                predecessors.put(target, node);
	                unSettledNodes.add(target);
	            }
	        }

	    }

	    
	    private double getDistance(Planet node, Planet target) {
	        for (Route edge : routes) {
	            if (edge.getPlanetOrigin().equals(node)
	                    && edge.getPlanetDestination().equals(target)) {
	                return edge.getDistanceLightYears();
	            }
	        }
	        throw new RuntimeException("Should not happen");
	    }

	    private List<Planet> getNeighbors(Planet node) {
	        List<Planet> neighbors = new ArrayList<Planet>();
	        for (Route edge : routes) {
	        	
	            if (edge.getPlanetOrigin().equals(node)
	                    && !isSettled(edge.getPlanetDestination())) {
	          
	                neighbors.add(edge.getPlanetDestination());
	            }
	        }
	        return neighbors;
	    }

	    private Planet getMinimum(Set<Planet> vertexes) {
	        Planet minimum = null;
	        for (Planet vertex : vertexes) {
	            if (minimum == null) {
	                minimum = vertex;
	            } else {
	                if (getShortestDistance(vertex) < getShortestDistance(minimum)) {
	                    minimum = vertex;
	                }
	            }
	        }
	        return minimum;
	    }

	    private boolean isSettled(Planet string) {
	        return settledNodes.contains(string);
	    }

	    private double getShortestDistance(Planet destination) {
	        Double d = distance.get(destination);
	        if (d == null) {
	            return Integer.MAX_VALUE;
	        } else {
	            return d;
	        }
	    }

	    /*
	     * This method returns the path from the source to the selected target and
	     * NULL if no path exists
	     */
	    public LinkedList<Planet> getPath(Planet target) {
	        LinkedList<Planet> path = new LinkedList<Planet>();
	        Planet step = target;
	        // check if a path exists
	        if (predecessors.get(step) == null) {
	            return null;
	        }
	        path.add(step);
	        while (predecessors.get(step) != null) {
	            step = predecessors.get(step);
	            path.add(step);
	        }
	        // Put it into the correct order
	        Collections.reverse(path);
	        return path;
	    }

	    
	    
}
