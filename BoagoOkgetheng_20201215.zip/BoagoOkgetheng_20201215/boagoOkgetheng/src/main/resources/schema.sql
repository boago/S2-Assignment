DROP TABLE IF EXISTS planet;

CREATE TABLE planet (
  planet_node VARCHAR(250) NOT NULL,
  planet_name VARCHAR(250) NOT NULL,
  PRIMARY KEY(planet_node)
);