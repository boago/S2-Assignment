package za.co.dinoko.assignment.boagoOkgetheng.controllerTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;
import za.co.dinoko.assignment.boagoOkgetheng.controller.AlgorithmController;
import za.co.dinoko.assignment.boagoOkgetheng.model.Graph;
import za.co.dinoko.assignment.boagoOkgetheng.model.Planet;
import za.co.dinoko.assignment.boagoOkgetheng.model.Route;

public class AlgorithmControllerTest {
	
	private List<Planet> nodes;
    private List<Route> edges;

    @Test
    public void testExcute() {
        nodes = new ArrayList<Planet>();
        edges = new ArrayList<Route>();
        for (int i = 0; i < 11; i++) {
           Planet location = new Planet("Node_ " + i, " Node_" + i);
            nodes.add(location);
        }

        addLane(0, 0, 1, 85);
        addLane(1, 0, 2, 217);
        addLane(2, 0, 4, 173);
        addLane(3, 2, 6, 186);
        addLane(4, 2, 7, 103);
        addLane(5, 3, 7, 183);
        addLane(6, 5, 8, 250);
        addLane(7, 8, 9, 84);
        addLane(8, 7, 9, 167);
        addLane(9, 4, 9, 502);
        addLane(10, 9, 10, 40);
        addLane(11, 1, 10, 600);

        // Lets check from location Loc_1 to Loc_10
        Graph graph = new Graph(nodes, edges);
        AlgorithmController algo = new AlgorithmController(graph);
        algo.execute(nodes.get(0));
        LinkedList<Planet> path = algo.getPath(nodes.get(10));

        assertNotNull(path);
        assertTrue(path.size() > 0);

        for (Planet vertex : path) {
            System.out.println(vertex + ",");
        }

    }
    

    private void addLane(int laneId, int sourceLocNo, int destLocNo,
            int duration) {
        Route lane = new Route(laneId,nodes.get(sourceLocNo), nodes.get(destLocNo), duration );
        edges.add(lane);
    }
}
