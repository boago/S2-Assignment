
Short Summary
By: Boago Okgetheng

Changed the data from A' to A2 because it was conflicting with the sql insert structure
I couldnt load the data using batch processing because i didnt have enough time then i decided to load it using the sql file.
I used H2 database
PostMan was used to access the data by adding, updating, deleting and listing the data.
The assignment is quite interesting and i believe given time i could do much better.
I used Dijkstra Algorithm which i learnt from my Masters algorithm class, i believe is the best choice because it finds the shortest path.
The algorithm works fine
To improve the system, I think visualization could be used so that we can see that particular shortest path after calculatons. 
